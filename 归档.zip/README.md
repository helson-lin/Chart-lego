# 慕课乐高标准模版

## 特性
* 开箱即用
* **typescript** 
* Vue3
* 支持 tsx
* eslint
* 简单易用可扩展