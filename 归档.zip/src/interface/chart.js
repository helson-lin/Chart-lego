import HttpRequest from "../lib/axios/index"
import DEMO from "../lib/chart-component/demo1"
export const getArticle = (uid) => {
	return {}
}
